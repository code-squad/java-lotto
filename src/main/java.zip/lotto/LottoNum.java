//package lotto;
//
//import java.util.*;
//
//public class LottoNum {
//    private static final int LOTTO_NUMBER_COUNT = 45;
//    private List<Integer> lottoNums = new ArrayList<>();
//
//    LottoNum() {
//        for (int i = 1; i <= LOTTO_NUMBER_COUNT; i++) {
//            lottoNums.add(i);
//        }
//        Collections.shuffle(lottoNums);
//    }
//
//}
