package lotto;

import dto.LottoDto;

import java.util.*;

public class Lotto {
    private static final int LOTTO_NUMBER_COUNT = 45;
    private static List<Integer> initLottoNumber = new ArrayList<>();
    private List<Integer> selectedLottoNumber;

    static {
        for (int i = 1; i <= LOTTO_NUMBER_COUNT; i++) {
            initLottoNumber.add(i);
        }
    }

    Lotto() {
        Collections.shuffle(initLottoNumber);
        selectedLottoNumber = new ArrayList<>(initLottoNumber.subList(0, 6));
        Collections.sort(selectedLottoNumber);
    }

    Lotto(TreeSet<Integer> winningLotto){
        selectedLottoNumber = new ArrayList(winningLotto);
        Collections.sort(selectedLottoNumber);
    }

    public LottoDto toDto() {
        return new LottoDto(this.selectedLottoNumber);
    }


    @Override
    public String toString() {
        return "" + selectedLottoNumber;
    }
}
