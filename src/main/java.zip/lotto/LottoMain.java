package lotto;

import java.util.*;

public class LottoMain {
    public static void main(String[] args) {
        int lottoCount = InputView.InputPurchase();
        PrintView.printLottoCount(lottoCount);

        LottoList lottoList = new LottoList(lottoCount);

        PrintView.printAutoLotto(lottoList.toDto());
//
//        Lotto winningLotto = new Lotto(InputView.intputWinningNumber());


    }
}
