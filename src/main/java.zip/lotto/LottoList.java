package lotto;

import dto.LottoDto;
import dto.LottoListDto;

import java.util.*;

public class LottoList {
    private List<Lotto> lottoList = new ArrayList<>();

    public LottoList(int count) {
        for (int i = 0; i < count; i++) {
            lottoList.add(new Lotto());
        }
    }

    public List<Lotto> getLottoList() {
        return lottoList;
    }

    public LottoListDto toDto() {
        List<LottoDto> lottoListDto = new ArrayList<>();

        for (Lotto lotto : lottoList) {
            lottoListDto.add(lotto.toDto());
        }

        return new LottoListDto(lottoListDto);
    }

}
