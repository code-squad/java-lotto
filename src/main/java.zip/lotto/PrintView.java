package lotto;

import dto.LottoDto;
import dto.LottoListDto;

import java.util.*;

public class PrintView {
    public static void printLottoCount(int count) {
        System.out.println(count + "개를 구매했습니다.");
    }

    public static void printAutoLotto(LottoListDto lottoListDto) {
        for (LottoDto lottoDto : lottoListDto.getLottoDtoList()) {
            System.out.println(lottoDto);
        }
    }

    public static void printResult() {
        System.out.println("당첨 통계");
        System.out.println("---------");
        System.out.println("3개 일치(5000원)");
        System.out.println("3개 일치(50000원)");
        System.out.println("3개 일치(1500000원)");
        System.out.println("3개 일치(2000000000원)");
    }

    public static void printResult(LottoList lottoList, List<Integer> winningLotto) {
        lottoList.getLottoList().get(0);
    }
}
