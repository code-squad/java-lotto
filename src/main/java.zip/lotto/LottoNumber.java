package lotto;

public class LottoNumber {
    private int number;

    LottoNumber(int number) throws IllegalArgumentException{
        if (number < 0 || number >46)
          throw new IllegalArgumentException();
        this.number = number;
    }

    LottoNumber(String number){
        this(Integer.parseInt(number));
    }
}
