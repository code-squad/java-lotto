package dto;

import lotto.LottoList;

import java.util.List;

public class LottoListDto {

    private List<LottoDto> lottoDtoList;

    public LottoListDto(List<LottoDto> lottoDtoList){
        this.lottoDtoList = lottoDtoList;
    }

    public List<LottoDto> getLottoDtoList() {
        return lottoDtoList;
    }
}
