package dto;

import java.util.List;

public class LottoDto {
    private List<Integer> lottoDto;

    public LottoDto(List<Integer> lottoDto) {
        this.lottoDto = lottoDto;
    }

    public List<Integer> getLottoDto() {
        return lottoDto;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < this.lottoDto.size(); i++) {
            sb.append(lottoDto.get(i));
            if(i < this.lottoDto.size()-1)
                sb.append(",");
        }
        sb.append("]");

        return sb.toString();
    }
}
