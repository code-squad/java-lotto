package vo;

public class No {

    private static final int MIN = 1;
    private static final int MAX = 45;

    private int no;

    public No(int no) {
        this.no = checkNo(no);
    }

    private int checkNo(int no) {
        if(no < MIN || no > MAX)
            throw new IllegalArgumentException("숫자가 너무 크거나 작습니다.");
        return no;
    }


    @Override
    public String toString() {
        return this.no + "";
    }
}
